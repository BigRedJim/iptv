#############Imports#############
import xbmc , xbmcaddon , xbmcgui , xbmcplugin , base64 , os , re , unicodedata , requests , time , string , sys , urllib , urllib2 , json , urlparse , datetime , zipfile , shutil
from resources . modules import client , control , tools
from datetime import date
import xml . etree . ElementTree as ElementTree
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
addon_id     = 'plugin.video.marvelv2'
selfAddon    = xbmcaddon.Addon(id=addon_id)
icon         = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
fanart       = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
accounticon  = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'account.png'))
livetvicon	 = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'livetv.png'))
catchupicon	 = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'catchup.png'))
vodicon	     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'vod.png')) 
seriesicon   = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'tv.png'))
settingsicon = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'settings.png'))
logouticon	 = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'logout.png'))
searchicon   = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'search.png'))
currenticon  = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'current.png'))
allowedicon  = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'allowed.png'))
usericon     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'user.png'))
passicon    = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'pass.png'))
cacheicon    = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'clear.png'))
advancedicon      = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'eas.png'))
speedicon    = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'speed.png'))
dataicon     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'meta.png'))
xxxicon      = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'xxx.png'))
dateicon     = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'date.png'))
statusicon      = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources/icons', 'status.png'))
if 22 - 22: OOo000 . O0I11i1i11i1I
Iiii = control . setting ( 'Username' )
OOO0O = control . setting ( 'Password' )
if 94 - 94: oooO0oOOOOo0o
O00OoOoo00 = 'http://saggybaws.co.uk'
iIiiI1 = '80'
if 68 - 68: Ii - OOoO00o + O000oo . iiIIi1IiIi11 . iIii1I111I11I . OO00OooO0OO
iiiIi = '%s:%s/enigma2.php?username=%s&password=%s&type=get_live_categories' % ( O00OoOoo00 , iIiiI1 , Iiii , OOO0O )
IiIIIiI1I1 = '%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories' % ( O00OoOoo00 , iIiiI1 , Iiii , OOO0O )
OoO000 = '%s:%s/enigma2.php?username=%s&password=%s&type=get_series_categories' % ( O00OoOoo00 , iIiiI1 , Iiii , OOO0O )
IIiiIiI1 = '%s:%s/panel_api.php?username=%s&password=%s' % ( O00OoOoo00 , iIiiI1 , Iiii , OOO0O )
iiIiIIi = '%s:%s/%s/%s/%s/' % ( O00OoOoo00 , iIiiI1 , type , Iiii , OOO0O )
ooOoo0O = '%s:%s/enigma2.php?username=%s&password=%s&type=get_series&cat_id=0' % ( O00OoOoo00 , iIiiI1 , Iiii , OOO0O )
if 76 - 76: i1II1I11 / i11iIiiIii / iIii1I11I1II1 . O0I11i1i11i1I % i1IIi
if 70 - 70: oooO0oOOOOo0o / iIii1I11I1II1 % i1II1I11 % i11iIiiIii . OOooo000oo0
advanced_settings           =  xbmc.translatePath('special://home/addons/'+addon_id+'/resources/advanced_settings')
advanced_settings_target    =  xbmc.translatePath(os.path.join('special://home/userdata','advancedsettings.xml'))
if 85 - 85: i1II1I11 . iiIIi1IiIi11 - ii1IiI1i % i1II1I11 % II111iiii
if 81 - 81: ii1IiI1i + II111iiii % iiIIi1IiIi11 * O0
if 89 - 89: oooO0oOOOOo0o + i1
def Ii1I ( ) :
 if Iiii == "" :
  Oo0o0 = III1ii1iII ( )
  oo0oooooO0 = i11Iiii ( )
  control . setSetting ( 'Username' , Oo0o0 )
  control . setSetting ( 'Password' , oo0oooooO0 )
  xbmc . executebuiltin ( 'Container.Refresh' )
  iI = '%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories' % ( O00OoOoo00 , iIiiI1 , Oo0o0 , oo0oooooO0 )
  iI = tools . OPEN_URL ( iI )
  iI = '%s:%s/enigma2.php?username=%s&password=%s&type=get_series_categories' % ( O00OoOoo00 , iIiiI1 , Oo0o0 , oo0oooooO0 )
  iI = tools . OPEN_URL ( iI )
  if iI == "" :
   I1i1I1II = "Login Details Incorrect"
   i1IiIiiI = "Please Try Again"
   I1I = ""
   xbmcgui . Dialog ( ) . ok ( 'Attention' , I1i1I1II , i1IiIiiI , I1I )
   Ii1I ( )
  else :
   I1i1I1II = "Login Successful"
   i1IiIiiI = "Welcome to Marvel!"
   I1I = ( '[COLOR red]%s[/COLOR]' % Oo0o0 )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , I1i1I1II , i1IiIiiI , I1I )
   oOO00oOO ( 'ADS2' , '' )
   xbmc . executebuiltin ( 'Container.Refresh' )
   OoOo ( )
 else :
  iI = '%s:%s/enigma2.php?username=%s&password=%s&type=get_vod_categories' % ( O00OoOoo00 , iIiiI1 , Iiii , OOO0O )
  iI = tools . OPEN_URL ( iI )
  iI = '%s:%s/enigma2.php?username=%s&password=%s&type=get_series_categories' % ( O00OoOoo00 , iIiiI1 , Iiii , OOO0O )
  iI = tools . OPEN_URL ( iI )
  if not iI == "" :
   tools . addDir ( '[B][COLOR white]Account Details[/COLOR][/B]' , 'url' , 6 , accounticon , fanart , '' )
   tools . addDir ( '[B][COLOR white]Live Channels[/COLOR][/B]' , 'live' , 1 , livetvicon , fanart , '' )
   tools . addDir ( '[B][COLOR white]Movies[/COLOR][/B]' , 'url' , 11 , vodicon , fanart , '' )
   tools . addDir ( '[B][COLOR white]TV Shows[/COLOR][/B]' , 'url' , 12 , seriesicon , fanart , '' )
   tools . addDir ( '[B][COLOR white]Tools[/COLOR][/B]' , 'url' , 16 , settingsicon , fanart , '' )
   tools . addDir ( '[B][COLOR white]Log Out[/COLOR][/B]' , 'LO' , 10 , logouticon , fanart , '' )
   if 18 - 18: i11iIiiIii
def OoOo ( ) :
 tools . addDir ( 'Account Details' , 'url' , 6 , icon , fanart , '' )
 tools . addDir ( 'Live Channels' , 'live' , 1 , icon , fanart , '' )
 tools . addDir ( 'Movies' , 'url' , 11 , icon , fanart , '' )
 tools . addDir ( 'TV Shows' , 'url' , 12 , icon , fanart , '' )
 tools . addDir ( 'Tools' , 'url' , 16 , icon , fanart , '' )
 tools . addDir ( 'Log Out' , 'LO' , 10 , icon , fanart , '' )
 if 46 - 46: i1IIi / OOoO00o % Ii + OO00OooO0OO
def O0OOO00oo ( url ) :
 if 31 - 31: II111iiii - Ii . OO00OooO0OO % IIIiiIIii - O0
 if not iIiiI1 in url :
  url = url . replace ( O00OoOoo00 , O00OoOoo00 + ':' + iIiiI1 )
 open = tools . OPEN_URL ( iiiIi )
 iii11 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for O0oo0OO0oOOOo in iii11 :
  i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
  i1i1i11IIi = base64 . b64decode ( i1i1i11IIi )
  II1III = tools . regex_from_to ( O0oo0OO0oOOOo , '<playlist_url>' , '</playlist_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
  if xbmcaddon . Addon ( ) . getSetting ( 'hidexxx' ) == 'true' :
   tools . addDir ( '%s' % i1i1i11IIi , II1III , 2 , icon , fanart , '' )
  else :
   if not 'XXX' in i1i1i11IIi :
    if not 'Adult' in i1i1i11IIi :
     tools . addDir ( '%s' % i1i1i11IIi , II1III , 2 , icon , fanart , '' )
     if 19 - 19: oooO0oOOOOo0o % i1IIi % OOo000
def oo0OooOOo0 ( url ) :
 if not iIiiI1 in url :
  url = url . replace ( O00OoOoo00 , O00OoOoo00 + ':' + iIiiI1 )
  open = tools . OPEN_URL ( url )
  iii11 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
  for O0oo0OO0oOOOo in iii11 :
   i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
   i1i1i11IIi = base64 . b64decode ( i1i1i11IIi )
   xbmc . log ( str ( i1i1i11IIi ) )
   try :
    i1i1i11IIi = re . sub ( '\[.*?min ' , '-' , i1i1i11IIi )
   except :
    pass
   o0O = tools . regex_from_to ( O0oo0OO0oOOOo , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
   II1III = tools . regex_from_to ( O0oo0OO0oOOOo , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
   O00oO = tools . regex_from_to ( O0oo0OO0oOOOo , '<description>' , '</description>' )
   if xbmcaddon . Addon ( ) . getSetting ( 'hidexxx' ) == 'true' :
    tools . addDir ( i1i1i11IIi , II1III , 4 , o0O , fanart , base64 . b64decode ( O00oO ) )
   else :
    if not 'XXX' in i1i1i11IIi :
     if not 'Adult' in i1i1i11IIi :
      tools . addDir ( i1i1i11IIi , II1III , 4 , o0O , fanart , base64 . b64decode ( O00oO ) )
      if 39 - 39: iIii1I111I11I - II111iiii * ii1IiI1i % OOo000 * II111iiii % II111iiii
def OoOOOOO ( url ) :
 if not iIiiI1 in url :
  url = url . replace ( O00OoOoo00 , O00OoOoo00 + ':' + iIiiI1 )
  if url == "vod" :
   open = tools . OPEN_URL ( IiIIIiI1I1 )
  else :
   open = tools . OPEN_URL ( url )
  iii11 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
  for O0oo0OO0oOOOo in iii11 :
   if '<playlist_url>' in open :
    i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
    II1III = tools . regex_from_to ( O0oo0OO0oOOOo , '<playlist_url>' , '</playlist_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    tools . addDir ( str ( base64 . b64decode ( i1i1i11IIi ) ) . replace ( '?' , '' ) , II1III , 3 , icon , fanart , '' )
   else :
    if xbmcaddon . Addon ( ) . getSetting ( 'meta' ) == 'true' :
     try :
      i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
      i1i1i11IIi = base64 . b64decode ( i1i1i11IIi )
      o0O = tools . regex_from_to ( O0oo0OO0oOOOo , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
      url = tools . regex_from_to ( O0oo0OO0oOOOo , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
      O00oO = tools . regex_from_to ( O0oo0OO0oOOOo , '<description>' , '</description>' )
      O00oO = base64 . b64decode ( O00oO )
      iIi1i111II = tools . regex_from_to ( O00oO , 'PLOT:' , '\n' )
      OoOO00O = tools . regex_from_to ( O00oO , 'CAST:' , '\n' )
      oOOoO0O0O0 = tools . regex_from_to ( O00oO , 'RATING:' , '\n' )
      Oo000o = tools . regex_from_to ( O00oO , 'RELEASEDATE:' , '\n' ) . replace ( ' ' , '-' )
      Oo000o = re . compile ( '-.*?-.*?-(.*?)-' , re . DOTALL ) . findall ( Oo000o )
      I11IiI1I11i1i = tools . regex_from_to ( O00oO , 'DURATION_SECS:' , '\n' )
      iI1ii1Ii = tools . regex_from_to ( O00oO , 'GENRE:' , '\n' )
      tools . addDirMeta ( str ( i1i1i11IIi ) . replace ( '[/COLOR].' , '.[/COLOR]' ) , url , 4 , o0O , fanart , iIi1i111II , str ( Oo000o ) . replace ( "['" , "" ) . replace ( "']" , "" ) , str ( OoOO00O ) . split ( ) , oOOoO0O0O0 , I11IiI1I11i1i , iI1ii1Ii )
     except : pass
     xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
    else :
     i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
     i1i1i11IIi = base64 . b64decode ( i1i1i11IIi )
     o0O = tools . regex_from_to ( O0oo0OO0oOOOo , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     url = tools . regex_from_to ( O0oo0OO0oOOOo , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     O00oO = tools . regex_from_to ( O0oo0OO0oOOOo , '<description>' , '</description>' )
     if xbmcaddon . Addon ( ) . getSetting ( 'hidexxx' ) == 'true' :
      tools . addDir ( i1i1i11IIi , url , 4 , o0O , fanart , base64 . b64decode ( O00oO ) )
     else :
      if not 'XXX' in i1i1i11IIi :
       if not 'Adult' in i1i1i11IIi :
        tools . addDir ( i1i1i11IIi , url , 4 , o0O , fanart , base64 . b64decode ( O00oO ) )
  xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
  if 92 - 92: IIIiiIIii
  if 26 - 26: iiIIi1IiIi11 . OO00OooO0OO
def oOOOOo0 ( url ) :
 if not iIiiI1 in url :
  url = url . replace ( O00OoOoo00 , O00OoOoo00 + ':' + iIiiI1 )
 iiII1i1 = o00oOO0o ( )
 if not iiII1i1 :
  xbmc . executebuiltin ( "XBMC.Notification([COLOR red][B]Search is Empty[/B][/COLOR],Aborting search,4000," + icon + ")" )
  return
 return OOO00O ( url , iiII1i1 )
 if 84 - 84: oooO0oOOOOo0o * ii1IiI1i / OOoO00o - O0
def OOO00O ( url , search = None ) :
 if not iIiiI1 in url :
  url = url . replace ( O00OoOoo00 , O00OoOoo00 + ':' + iIiiI1 )
  if 30 - 30: iIii1I11I1II1 / i1II1I11 - OO00OooO0OO - II111iiii % iiIIi1IiIi11
 open = tools . OPEN_URL ( url )
 if 49 - 49: OOooo000oo0 % i1II1I11 . i1II1I11 . OOoO00o * i1II1I11
 iii11 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for O0oo0OO0oOOOo in iii11 :
  if '<playlist_url>' in open :
   i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
   i1i1i11IIi = base64 . b64decode ( i1i1i11IIi )
   II1III = tools . regex_from_to ( O0oo0OO0oOOOo , '<playlist_url>' , '</playlist_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
   if 97 - 97: O000oo + OOo000 . Ii + O0I11i1i11i1I % iiIIi1IiIi11
   if search == None or ( search . lower ( ) in i1i1i11IIi . lower ( ) ) :
    tools . addDir ( str ( i1i1i11IIi ) . replace ( '?' , '' ) , II1III , 24 , icon , fanart , '' )
  else :
   if xbmcaddon . Addon ( ) . getSetting ( 'meta' ) == 'true' :
    try :
     i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
     i1i1i11IIi = base64 . b64decode ( i1i1i11IIi )
     o0O = tools . regex_from_to ( O0oo0OO0oOOOo , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     url = tools . regex_from_to ( O0oo0OO0oOOOo , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     O00oO = tools . regex_from_to ( O0oo0OO0oOOOo , '<description>' , '</description>' )
     O00oO = base64 . b64decode ( O00oO )
     iIi1i111II = tools . regex_from_to ( O00oO , 'PLOT:' , '\n' )
     OoOO00O = tools . regex_from_to ( O00oO , 'CAST:' , '\n' )
     oOOoO0O0O0 = tools . regex_from_to ( O00oO , 'RATING:' , '\n' )
     Oo000o = tools . regex_from_to ( O00oO , 'RELEASEDATE:' , '\n' ) . replace ( ' ' , '-' )
     Oo000o = re . compile ( '-.*?-.*?-(.*?)-' , re . DOTALL ) . findall ( Oo000o )
     I11IiI1I11i1i = tools . regex_from_to ( O00oO , 'DURATION_SECS:' , '\n' )
     iI1ii1Ii = tools . regex_from_to ( O00oO , 'GENRE:' , '\n' )
     tools . addDirMeta ( str ( i1i1i11IIi ) . replace ( '[/COLOR].' , '.[/COLOR]' ) , url , 4 , o0O , fanart , iIi1i111II , str ( Oo000o ) . replace ( "['" , "" ) . replace ( "']" , "" ) , str ( OoOO00O ) . split ( ) , oOOoO0O0O0 , I11IiI1I11i1i , iI1ii1Ii )
    except : pass
    xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'tvshows' )
   else :
    i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
    i1i1i11IIi = base64 . b64decode ( i1i1i11IIi )
    o0O = tools . regex_from_to ( O0oo0OO0oOOOo , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    url = tools . regex_from_to ( O0oo0OO0oOOOo , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    O00oO = tools . regex_from_to ( O0oo0OO0oOOOo , '<description>' , '</description>' )
    tools . addDir ( i1i1i11IIi , url , 4 , o0O , fanart , base64 . b64decode ( O00oO ) )
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 if 95 - 95: i1IIi
 if 3 - 3: OO00OooO0OO - O0 / OO00OooO0OO % ii1IiI1i / OO00OooO0OO . OOooo000oo0
 if 50 - 50: iIii1I111I11I
def i11I1iIiII ( url ) :
 if not iIiiI1 in url :
  url = url . replace ( O00OoOoo00 , O00OoOoo00 + ':' + iIiiI1 )
 if url == "seasons" :
  open = tools . OPEN_URL ( seasons_url )
 else :
  open = tools . OPEN_URL ( url )
 iii11 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for O0oo0OO0oOOOo in iii11 :
  if '<playlist_url>' in open :
   i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
   II1III = tools . regex_from_to ( O0oo0OO0oOOOo , '<playlist_url>' , '</playlist_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
   tools . addDir ( str ( base64 . b64decode ( i1i1i11IIi ) ) . replace ( '?' , '' ) , II1III , 21 , icon , fanart , '' )
  else :
   if xbmcaddon . Addon ( ) . getSetting ( 'meta' ) == 'true' :
    try :
     i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
     i1i1i11IIi = base64 . b64decode ( i1i1i11IIi )
     o0O = tools . regex_from_to ( O0oo0OO0oOOOo , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     url = tools . regex_from_to ( O0oo0OO0oOOOo , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     O00oO = tools . regex_from_to ( O0oo0OO0oOOOo , '<description>' , '</description>' )
     O00oO = base64 . b64decode ( O00oO )
     iIi1i111II = tools . regex_from_to ( O00oO , 'PLOT:' , '\n' )
     OoOO00O = tools . regex_from_to ( O00oO , 'CAST:' , '\n' )
     oOOoO0O0O0 = tools . regex_from_to ( O00oO , 'RATING:' , '\n' )
     Oo000o = tools . regex_from_to ( O00oO , 'RELEASEDATE:' , '\n' ) . replace ( ' ' , '-' )
     Oo000o = re . compile ( '-.*?-.*?-(.*?)-' , re . DOTALL ) . findall ( Oo000o )
     I11IiI1I11i1i = tools . regex_from_to ( O00oO , 'DURATION_SECS:' , '\n' )
     iI1ii1Ii = tools . regex_from_to ( O00oO , 'GENRE:' , '\n' )
     tools . addDirMeta ( str ( i1i1i11IIi ) . replace ( '[/COLOR].' , '.[/COLOR]' ) , url , 4 , o0O , fanart , iIi1i111II , str ( Oo000o ) . replace ( "['" , "" ) . replace ( "']" , "" ) , str ( OoOO00O ) . split ( ) , oOOoO0O0O0 , I11IiI1I11i1i , iI1ii1Ii )
    except : pass
    xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'tvshows' )
   else :
    i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
    i1i1i11IIi = base64 . b64decode ( i1i1i11IIi )
    o0O = tools . regex_from_to ( O0oo0OO0oOOOo , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    url = tools . regex_from_to ( O0oo0OO0oOOOo , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    O00oO = tools . regex_from_to ( O0oo0OO0oOOOo , '<description>' , '</description>' )
    tools . addDir ( i1i1i11IIi , url , 4 , o0O , fanart , base64 . b64decode ( O00oO ) )
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 if 96 - 96: i1
 if 45 - 45: O0 * OOo000 % i1 * OoooooooOO + iiIIi1IiIi11 . IIIiiIIii
 if 67 - 67: i11iIiiIii - i1IIi % O0I11i1i11i1I . O0
def o0oo ( url ) :
 if not iIiiI1 in url :
  url = url . replace ( O00OoOoo00 , O00OoOoo00 + ':' + iIiiI1 )
 open = tools . OPEN_URL ( url )
 if 91 - 91: iIii1I111I11I
 iii11 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for O0oo0OO0oOOOo in iii11 :
  if '<playlist_url>' in open :
   i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
   II1III = tools . regex_from_to ( O0oo0OO0oOOOo , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
   tools . addDir ( str ( base64 . b64decode ( i1i1i11IIi ) ) . replace ( '?' , '' ) , II1III , 22 , icon , fanart , '' )
  else :
   if xbmcaddon . Addon ( ) . getSetting ( 'meta' ) == 'true' :
    try :
     i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
     i1i1i11IIi = base64 . b64decode ( i1i1i11IIi )
     o0O = tools . regex_from_to ( O0oo0OO0oOOOo , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     url = tools . regex_from_to ( O0oo0OO0oOOOo , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     O00oO = tools . regex_from_to ( O0oo0OO0oOOOo , '<description>' , '</description>' )
     O00oO = base64 . b64decode ( O00oO )
     iIi1i111II = tools . regex_from_to ( O00oO , 'PLOT:' , '\n' )
     OoOO00O = tools . regex_from_to ( O00oO , 'CAST:' , '\n' )
     oOOoO0O0O0 = tools . regex_from_to ( O00oO , 'RATING:' , '\n' )
     Oo000o = tools . regex_from_to ( O00oO , 'RELEASEDATE:' , '\n' ) . replace ( ' ' , '-' )
     Oo000o = re . compile ( '-.*?-.*?-(.*?)-' , re . DOTALL ) . findall ( Oo000o )
     I11IiI1I11i1i = tools . regex_from_to ( O00oO , 'DURATION_SECS:' , '\n' )
     iI1ii1Ii = tools . regex_from_to ( O00oO , 'GENRE:' , '\n' )
     tools . addDirMeta ( str ( i1i1i11IIi ) . replace ( '[/COLOR].' , '.[/COLOR]' ) , url , 4 , o0O , fanart , iIi1i111II , str ( Oo000o ) . replace ( "['" , "" ) . replace ( "']" , "" ) , str ( OoOO00O ) . split ( ) , oOOoO0O0O0 , I11IiI1I11i1i , iI1ii1Ii )
    except : pass
    xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'episodes' )
   else :
    i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
    i1i1i11IIi = base64 . b64decode ( i1i1i11IIi )
    o0O = tools . regex_from_to ( O0oo0OO0oOOOo , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    url = tools . regex_from_to ( O0oo0OO0oOOOo , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    O00oO = tools . regex_from_to ( O0oo0OO0oOOOo , '<description>' , '</description>' )
    tools . addDir ( i1i1i11IIi , url , 4 , o0O , fanart , base64 . b64decode ( O00oO ) )
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 if 15 - 15: II111iiii
 if 18 - 18: i11iIiiIii . i1IIi % OoooooooOO / O0
def OO0OoO0o00 ( url ) :
 if not iIiiI1 in url :
  url = url . replace ( O00OoOoo00 , O00OoOoo00 + ':' + iIiiI1 )
 log ( url )
 if url == "vod" :
  open = tools . OPEN_URL ( IiIIIiI1I1 )
 else :
  open = tools . OPEN_URL ( url )
 log ( open )
 iii11 = tools . regex_get_all ( open , '<channel>' , '</channel>' )
 for O0oo0OO0oOOOo in iii11 :
  if '<playlist_url>' in open :
   i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
   II1III = tools . regex_from_to ( O0oo0OO0oOOOo , '<playlist_url>' , '</playlist_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
   tools . addDir ( str ( base64 . b64decode ( i1i1i11IIi ) ) . replace ( '?' , '' ) , II1III , 20 , icon , fanart , '' )
  else :
   if xbmcaddon . Addon ( ) . getSetting ( 'meta' ) == 'true' :
    try :
     i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
     i1i1i11IIi = base64 . b64decode ( i1i1i11IIi )
     o0O = tools . regex_from_to ( O0oo0OO0oOOOo , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     url = tools . regex_from_to ( O0oo0OO0oOOOo , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
     O00oO = tools . regex_from_to ( O0oo0OO0oOOOo , '<description>' , '</description>' )
     O00oO = base64 . b64decode ( O00oO )
     iIi1i111II = tools . regex_from_to ( O00oO , 'PLOT:' , '\n' )
     OoOO00O = tools . regex_from_to ( O00oO , 'CAST:' , '\n' )
     oOOoO0O0O0 = tools . regex_from_to ( O00oO , 'RATING:' , '\n' )
     Oo000o = tools . regex_from_to ( O00oO , 'RELEASEDATE:' , '\n' ) . replace ( ' ' , '-' )
     Oo000o = re . compile ( '-.*?-.*?-(.*?)-' , re . DOTALL ) . findall ( Oo000o )
     I11IiI1I11i1i = tools . regex_from_to ( O00oO , 'DURATION_SECS:' , '\n' )
     iI1ii1Ii = tools . regex_from_to ( O00oO , 'GENRE:' , '\n' )
     tools . addDirMeta ( str ( i1i1i11IIi ) . replace ( '[/COLOR].' , '.[/COLOR]' ) , url , 4 , o0O , fanart , iIi1i111II , str ( Oo000o ) . replace ( "['" , "" ) . replace ( "']" , "" ) , str ( OoOO00O ) . split ( ) , oOOoO0O0O0 , I11IiI1I11i1i , iI1ii1Ii )
    except : pass
    xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'tvshows' )
   else :
    i1i1i11IIi = tools . regex_from_to ( O0oo0OO0oOOOo , '<title>' , '</title>' )
    i1i1i11IIi = base64 . b64decode ( i1i1i11IIi )
    o0O = tools . regex_from_to ( O0oo0OO0oOOOo , '<desc_image>' , '</desc_image>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    url = tools . regex_from_to ( O0oo0OO0oOOOo , '<stream_url>' , '</stream_url>' ) . replace ( '<![CDATA[' , '' ) . replace ( ']]>' , '' )
    O00oO = tools . regex_from_to ( O0oo0OO0oOOOo , '<description>' , '</description>' )
    tools . addDir ( i1i1i11IIi , url , 4 , o0O , fanart , base64 . b64decode ( O00oO ) )
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 if 53 - 53: O0 * ii1IiI1i + Ii
 if 50 - 50: O0 . O0 - oooO0oOOOOo0o / OOooo000oo0 - OOo000 * IIIiiIIii
 if 61 - 61: OOoO00o
def O0oOoOOOoOO ( url ) :
 if not iIiiI1 in url :
  url = url . replace ( O00OoOoo00 , O00OoOoo00 + ':' + iIiiI1 )
 url = str ( url ) . replace ( 'USERNAME' , Iiii ) . replace ( 'PASSWORD' , OOO0O )
 url = url + '|' + 'User-Agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0&Referer=' + url
 ii1ii11IIIiiI = xbmcgui . ListItem ( '' , iconImage = 'DefaultVideo.png' , thumbnailImage = icon )
 ii1ii11IIIiiI . setInfo ( type = 'Video' , infoLabels = { 'Title' : '' , 'Plot' : '' } )
 ii1ii11IIIiiI . setProperty ( 'IsPlayable' , 'true' )
 ii1ii11IIIiiI . setPath ( str ( url ) )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , ii1ii11IIIiiI )
 if 67 - 67: OOoO00o * oooO0oOOOOo0o * O0I11i1i11i1I + Ii / i1IIi
 if 11 - 11: O000oo + iiIIi1IiIi11 - i1II1I11 * oooO0oOOOOo0o % i11iIiiIii - OO00OooO0OO
def o0oO ( ) :
 tools . addDir ( '[COLOR white]All Movies[/COLOR]' , 'vod' , 333 , vodicon , fanart , '' )
 tools . addDir ( '[COLOR white]Movie Categories[/COLOR]' , 'vod' , 3 , vodicon , fanart , '' )
 tools . addDir ( '[COLOR white]Search Movies[/COLOR]' , 'url' , 5 , searchicon , fanart , '' )
 if 1 - 1: ii1IiI1i - oooO0oOOOOo0o . OOoO00o . ii1IiI1i / i1 + OOoO00o
def Ooo ( ) :
 tools . addDir ( '[COLOR white]TV Show Categories[/COLOR]' , OoO000 , 24 , seriesicon , fanart , '' )
 tools . addDir ( '[COLOR white]Search TV Shows[/COLOR]' , ooOoo0O , 2424 , searchicon , fanart , '' )
 if 62 - 62: Ii / ii1IiI1i + O000oo / ii1IiI1i . II111iiii
def o00oOO0o ( ) :
 ooOOoooooo = control . inputDialog ( heading = 'Search Marvel:' )
 if ooOOoooooo == "" :
  return
 else :
  return ooOOoooooo
  if 1 - 1: i1 / OOo000 % iiIIi1IiIi11 * iIii1I111I11I . i11iIiiIii
  if 2 - 2: O0I11i1i11i1I * OOoO00o - iIii1I11I1II1 + OOooo000oo0 . oooO0oOOOOo0o % iiIIi1IiIi11
def ooOOoooooo ( ) :
 if ooOOOoOooOoO == ( [ 3 , 4 , 20 , 21 ] ) :
  return False
  if 91 - 91: iiIIi1IiIi11 % i1IIi % iIii1I11I1II1
 iiII1i1 = xbmcgui . Dialog ( ) . input ( "Search for a Movie ?" )
 xbmc . log ( repr ( iiII1i1 ) , xbmc . LOGERROR )
 if not iiII1i1 :
  xbmc . executebuiltin ( "XBMC.Notification([COLOR red][B]Search is Empty[/B][/COLOR],Aborting search,4000," + icon + ")" )
  return
 xbmc . log ( str ( iiII1i1 ) )
 open = tools . OPEN_URL ( IIiiIiI1 )
 import json
 IIi1I11I1II = json . loads ( open )
 OooOoooOo = IIi1I11I1II [ "available_channels" ]
 for id , ii11IIII11I in OooOoooOo . items ( ) :
  i1i1i11IIi = ii11IIII11I [ "name" ] or ''
  type = ii11IIII11I [ "stream_type" ] or ''
  OOooo = ii11IIII11I [ "container_extension" ] or ''
  o0O = ii11IIII11I [ "stream_icon" ] or ''
  fanart = ''
  ii1ii11IIIiiI = xbmcgui . ListItem ( i1i1i11IIi , iconImage = o0O , thumbnailImage = o0O )
  ii1ii11IIIiiI . setInfo ( type = "Video" , infoLabels = { "Title" : i1i1i11IIi , "Plot" : '' , } )
  ii1ii11IIIiiI . setProperty ( 'fanart_image' , fanart )
  ii1ii11IIIiiI . setProperty ( "IsPlayable" , "true" )
  iiIiIIi = '%s:%s/%s/%s/%s/' % ( O00OoOoo00 , iIiiI1 , type , Iiii , OOO0O )
  xbmc . log ( repr ( i1i1i11IIi ) )
  if iiII1i1 in i1i1i11IIi . lower ( ) :
   if 90 - 90: OOo000 % i1IIi / ii1IiI1i
   iiIiIIi = '%s:%s/%s/%s/%s/' % ( O00OoOoo00 , iIiiI1 , type , Iiii , OOO0O )
   IIi = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIiIIi + id + '.' + OOooo , listitem = ii1ii11IIIiiI , isFolder = False )
  elif iiII1i1 not in i1i1i11IIi . lower ( ) and iiII1i1 in i1i1i11IIi :
   if 41 - 41: O000oo - O0 - O0
   iiIiIIi = '%s:%s/%s/%s/%s/' % ( O00OoOoo00 , iIiiI1 , type , Iiii , OOO0O )
   IIi = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIiIIi + id + '.' + OOooo , listitem = ii1ii11IIIiiI , isFolder = False )
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_TITLE )
 if 68 - 68: Ii % OO00OooO0OO
def ooO00OO0 ( ) :
 tools . addDir ( 'Log Out' , 'LO' , 10 , icon , fanart , '' )
 if 31 - 31: iiIIi1IiIi11 % iiIIi1IiIi11 % OOoO00o
 if 69 - 69: ii1IiI1i - i1 + i1IIi / OO00OooO0OO
def oOO00oOO ( url , description ) :
 if url == "CC" :
  tools . clear_cache ( )
 elif url == "AS" :
  xbmc . executebuiltin ( 'Addon.OpenSettings(%s)' % IiII1IiiIiI1 )
 elif url == "ADS" :
  ii1 = xbmcgui . Dialog ( ) . select ( 'Edit Advanced Settings' , [ 'Enable Fire TV Stick AS' , 'Enable Fire TV AS' , 'Enable 1GB Ram or Lower AS' , 'Enable 2GB Ram or Higher AS' , 'Enable Nvidia Shield AS' , 'Disable AS' ] )
  if ii1 == 0 :
   I1iI1iIi111i ( 'stick' )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'Set Advanced Settings' )
  elif ii1 == 1 :
   I1iI1iIi111i ( 'firetv' )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'Set Advanced Settings' )
  elif ii1 == 2 :
   I1iI1iIi111i ( 'lessthan' )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'Set Advanced Settings' )
  elif ii1 == 3 :
   I1iI1iIi111i ( 'morethan' )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'Set Advanced Settings' )
  elif ii1 == 4 :
   I1iI1iIi111i ( 'shield' )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'Set Advanced Settings' )
  elif ii1 == 5 :
   I1iI1iIi111i ( 'remove' )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'Advanced Settings Removed' )
 elif url == "ADS2" :
  ii1 = xbmcgui . Dialog ( ) . select ( 'Select Your Device Or Closest To' , [ 'Fire TV Stick ' , 'Fire TV' , '1GB Ram or Lower' , '2GB Ram or Higher' , 'Nvidia Shield' ] )
  if ii1 == 0 :
   I1iI1iIi111i ( 'stick' )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'Set Advanced Settings' )
  elif ii1 == 1 :
   I1iI1iIi111i ( 'firetv' )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'Set Advanced Settings' )
  elif ii1 == 2 :
   I1iI1iIi111i ( 'lessthan' )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'Set Advanced Settings' )
  elif ii1 == 3 :
   I1iI1iIi111i ( 'morethan' )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'Set Advanced Settings' )
  elif ii1 == 4 :
   I1iI1iIi111i ( 'shield' )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'Set Advanced Settings' )
 elif url == "tv" :
  ii1 = xbmcgui . Dialog ( ) . select ( 'Select a TV Guide to Setup' , [ 'iVue TV Guide' , 'PVR TV Guide' , 'Both' ] )
  if ii1 == 0 :
   ivueint ( )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'iVue Integration Complete' )
  elif ii1 == 1 :
   pvrsetup ( )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'PVR Integration Complete' )
  elif ii1 == 2 :
   pvrsetup ( )
   ivueint ( )
   xbmcgui . Dialog ( ) . ok ( 'Marvel' , 'PVR & iVue Integration Complete' )
 elif url == "ST" :
  xbmc . executebuiltin ( 'Runscript("special://home/addons/plugin.video.marvelv2/resources/modules/speedtest.py")' )
 elif url == "META" :
  if 'ON' in description :
   xbmcaddon . Addon ( ) . setSetting ( 'meta' , 'false' )
   xbmc . executebuiltin ( 'Container.Refresh' )
  else :
   xbmcaddon . Addon ( ) . setSetting ( 'meta' , 'true' )
   xbmc . executebuiltin ( 'Container.Refresh' )
 elif url == "XXX" :
  if 'ON' in description :
   xbmcaddon . Addon ( ) . setSetting ( 'hidexxx' , 'false' )
   xbmc . executebuiltin ( 'Container.Refresh' )
  else :
   xbmcaddon . Addon ( ) . setSetting ( 'hidexxx' , 'true' )
   xbmc . executebuiltin ( 'Container.Refresh' )
 elif url == "LO" :
  xbmcaddon . Addon ( ) . setSetting ( 'Username' , '' )
  xbmcaddon . Addon ( ) . setSetting ( 'Password' , '' )
  xbmc . executebuiltin ( 'XBMC.ActivateWindow(Videos,addons://sources/video/)' )
  xbmc . executebuiltin ( 'Container.Refresh' )
 elif url == "UPDATE" :
  if 'ON' in description :
   xbmcaddon . Addon ( ) . setSetting ( 'update' , 'false' )
   xbmc . executebuiltin ( 'Container.Refresh' )
  else :
   xbmcaddon . Addon ( ) . setSetting ( 'update' , 'true' )
   xbmc . executebuiltin ( 'Container.Refresh' )
   if 44 - 44: i1IIi % II111iiii + OOoO00o
def I1I1I ( ) :
 open = tools . OPEN_URL ( IIiiIiI1 )
 import json
 IIi1I11I1II = json . loads ( open )
 OooOoooOo = IIi1I11I1II [ "available_channels" ]
 for id , ii11IIII11I in OooOoooOo . items ( ) :
  i1i1i11IIi = ii11IIII11I [ "name" ] or ''
  type = ii11IIII11I [ "stream_type" ] or ''
  OOooo = ii11IIII11I [ "container_extension" ] or ''
  o0O = ii11IIII11I [ "stream_icon" ] or ''
  fanart = ''
  ii1ii11IIIiiI = xbmcgui . ListItem ( i1i1i11IIi , iconImage = o0O , thumbnailImage = o0O )
  ii1ii11IIIiiI . setInfo ( type = "Video" , infoLabels = { "Title" : i1i1i11IIi , "Plot" : '' , } )
  ii1ii11IIIiiI . setProperty ( 'fanart_image' , fanart )
  ii1ii11IIIiiI . setProperty ( "IsPlayable" , "true" )
  iiIiIIi = '%s:%s/%s/%s/%s/' % ( O00OoOoo00 , iIiiI1 , type , Iiii , OOO0O )
  IIi = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiIiIIi + id + '.' + OOooo , listitem = ii1ii11IIIiiI , isFolder = False )
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_VIDEO_TITLE )
 if 95 - 95: II111iiii + OOo000 + iiIIi1IiIi11 * iIii1I11I1II1 % oooO0oOOOOo0o / iIii1I111I11I
def I1iI1iIi111i ( device ) :
 if device == 'stick' :
  file = open ( os . path . join ( O0o0Oo , 'stick.xml' ) )
 elif device == 'firetv' :
  file = open ( os . path . join ( O0o0Oo , 'firetv.xml' ) )
 elif device == 'lessthan' :
  file = open ( os . path . join ( O0o0Oo , 'lessthan1GB.xml' ) )
 elif device == 'morethan' :
  file = open ( os . path . join ( O0o0Oo , 'morethan1GB.xml' ) )
 elif device == 'shield' :
  file = open ( os . path . join ( O0o0Oo , 'shield.xml' ) )
 elif device == 'remove' :
  os . remove ( Oo00OOOOO )
  if 56 - 56: iiIIi1IiIi11
 try :
  oo0oO0oOOoo = file . read ( )
  oOo00O0oo00o0 = open ( Oo00OOOOO , mode = 'w+' )
  oOo00O0oo00o0 . write ( oo0oO0oOOoo )
  oOo00O0oo00o0 . close ( )
 except :
  pass
  if 45 - 45: O0
  if 26 - 26: OOoO00o - iIii1I11I1II1 - OOooo000oo0 / ii1IiI1i . IIIiiIIii % iIii1I11I1II1
def OO ( ) :
 iIiIIi1 = xbmcgui . Dialog ( ) . yesno ( 'Marvel' , 'Please Select The RAM Size of Your Device' , yeslabel = 'Less than 1GB RAM' , nolabel = 'More than 1GB RAM' )
 if iIiIIi1 :
  I1IIII1i ( )
 else :
  I1I11i ( )
  if 5 - 5: OoooooooOO % IIIiiIIii % oooO0oOOOOo0o % iiIIi1IiIi11
  if 7 - 7: II111iiii + OoooooooOO . OO00OooO0OO . i1II1I11 - OOo000
def I1I11i ( ) :
 file = open ( os . path . join ( O0o0Oo , 'morethan.xml' ) )
 O0oo0OO0oOOOo = file . read ( )
 oOo00O0oo00o0 = open ( Oo00OOOOO , mode = 'w+' )
 oOo00O0oo00o0 . write ( O0oo0OO0oOOOo )
 oOo00O0oo00o0 . close ( )
 if 26 - 26: i1 / iIii1I111I11I % iIii1I11I1II1 / iIii1I111I11I + OOoO00o
 if 90 - 90: IIIiiIIii * OO00OooO0OO + OOo000
def I1IIII1i ( ) :
 file = open ( os . path . join ( O0o0Oo , 'lessthan.xml' ) )
 O0oo0OO0oOOOo = file . read ( )
 oOo00O0oo00o0 = open ( Oo00OOOOO , mode = 'w+' )
 oOo00O0oo00o0 . write ( O0oo0OO0oOOOo )
 oOo00O0oo00o0 . close ( )
 if 81 - 81: oooO0oOOOOo0o . OOo000 % O0 / OOooo000oo0 - oooO0oOOOOo0o
 if 43 - 43: i11iIiiIii + i1 * II111iiii * OO00OooO0OO * O0
def III1ii1iII ( ) :
 o00oO0oo0OO = xbmc . Keyboard ( '' , 'heading' , True )
 o00oO0oo0OO . setHeading ( 'Enter Username' )
 o00oO0oo0OO . setHiddenInput ( False )
 o00oO0oo0OO . doModal ( )
 if ( o00oO0oo0OO . isConfirmed ( ) ) :
  iiII1i1 = o00oO0oo0OO . getText ( )
  return iiII1i1
 else :
  return False
  if 57 - 57: OO00OooO0OO % O000oo + OOo000 - i1
  if 65 - 65: OOoO00o . IIIiiIIii
def i11Iiii ( ) :
 o00oO0oo0OO = xbmc . Keyboard ( '' , 'heading' , True )
 o00oO0oo0OO . setHeading ( 'Enter Password' )
 o00oO0oo0OO . setHiddenInput ( False )
 o00oO0oo0OO . doModal ( )
 if ( o00oO0oo0OO . isConfirmed ( ) ) :
  iiII1i1 = o00oO0oo0OO . getText ( )
  return iiII1i1
 else :
  return False
  if 39 - 39: II111iiii / i1II1I11 + OO00OooO0OO / IIIiiIIii
  if 13 - 13: iIii1I111I11I + O0 + iiIIi1IiIi11 % OOooo000oo0 / OOo000 . iIii1I111I11I
def OO0Oooo0oOO0O ( ) :
 open = tools . OPEN_URL ( IIiiIiI1 )
 try:
  username   = tools.regex_from_to(open,'"username":"','"')
  password   = tools.regex_from_to(open,'"password":"','"')
  status     = tools.regex_from_to(open,'"status":"','"')
  connects   = tools.regex_from_to(open,'"max_connections":"','"')
  active     = tools.regex_from_to(open,'"active_cons":"','"')
  expiry     = tools.regex_from_to(open,'"exp_date":"','"')
  expiry     = datetime.datetime.fromtimestamp(int(expiry)).strftime('%d/%m/%Y - %H:%M')
  expreg     = re.compile('^(.*?)/(.*?)/(.*?)$',re.DOTALL).findall(expiry)
  for day,month,year in expreg:
   month     = tools.MonthNumToName(month)
   year      = re.sub(' -.*?$','',year)
   expiry    = month+' '+day+' - '+year
   tools.addDir('[B][COLOR red]Account Status :[/COLOR][/B] %s'%status,'','',statusicon,fanart,'')
   tools.addDir('[B][COLOR red]Expiry Date:[/COLOR][/B] '+expiry,'','',dateicon,fanart,'')
   tools.addDir('[B][COLOR red]Username :[/COLOR][/B] '+username,'','',usericon,fanart,'')
   tools.addDir('[B][COLOR red]Password :[/COLOR][/B] '+password,'','',passicon,fanart,'')
   tools.addDir('[B][COLOR red]Allowed Connections:[/COLOR][/B] '+connects,'','',allowedicon,fanart,'')
   tools.addDir('[B][COLOR red]Current Connections:[/COLOR][/B] '+ active,'','',currenticon,fanart,'')
 except:pass
 if 32 - 32: i1IIi / II111iiii . i1
 if 62 - 62: OoooooooOO * OOooo000oo0
def oOOOoo0O0oO ( ) :
	if xbmcaddon.Addon().getSetting('meta')=='true':
		META = '[B][COLOR lime]ON[/COLOR][/B]'
	else:
		META = '[B][COLOR red]OFF[/COLOR][/B]'
	if xbmcaddon.Addon().getSetting('hidexxx')=='true':
		XXX = '[B][COLOR lime]ON[/COLOR][/B]'
	else:
		XXX = '[B][COLOR red]OFF[/COLOR][/B]'
	tools.addDir('Metadata is %s'%META,'META',10,dataicon,fanart,META)
	tools.addDir('XXX Channels are %s'%XXX,'XXX',10,xxxicon,fanart,XXX)
	tools.addDir('Clear Cache','CC',10,cacheicon,fanart,'')
	tools.addDir('Edit Advanced Settings','ADS',10,advancedicon,fanart,'')
	tools.addDir('Run a Speed Test','ST',10,speedicon,fanart,'')
if 20 - 20: OOo000 . II111iiii % Ii * iIii1I11I1II1
if 98 - 98: OOooo000oo0 % O000oo * OoooooooOO
Oo = tools . get_params ( )
iIIiIi1 = None
i1i1i11IIi = None
ooOOOoOooOoO = None
o0O0o0 = None
II111iI111I1I = None
I1i1i1iii = None
type = None
if 16 - 16: O000oo + iIii1I111I11I * O0 % i1IIi . OOooo000oo0
try :
 iIIiIi1 = urllib . unquote_plus ( Oo [ "url" ] )
except :
 pass
try :
 i1i1i11IIi = urllib . unquote_plus ( Oo [ "name" ] )
except :
 pass
try :
 o0O0o0 = urllib . unquote_plus ( Oo [ "iconimage" ] )
except :
 pass
try :
 ooOOOoOooOoO = int ( Oo [ "mode" ] )
except :
 pass
try :
 II111iI111I1I = urllib . unquote_plus ( Oo [ "description" ] )
except :
 pass
try :
 I1i1i1iii = urllib . unquote_plus ( Oo [ "query" ] )
except :
 pass
try :
 type = urllib . unquote_plus ( Oo [ "type" ] )
except :
 pass
 if 67 - 67: OoooooooOO / OOooo000oo0 * O000oo + OOoO00o
if ooOOOoOooOoO == None or iIIiIi1 == None or len ( iIIiIi1 ) < 1 :
 Ii1I ( )
 if 65 - 65: OoooooooOO - O0I11i1i11i1I / i1II1I11 / II111iiii / i1IIi
elif ooOOOoOooOoO == 1 :
 O0OOO00oo ( iIIiIi1 )
 if 71 - 71: OO00OooO0OO + O000oo
elif ooOOOoOooOoO == 2 :
 oo0OooOOo0 ( iIIiIi1 )
 if 28 - 28: Ii
elif ooOOOoOooOoO == 3 :
 OoOOOOO ( iIIiIi1 )
 if 38 - 38: i1II1I11 % II111iiii % OOoO00o / ii1IiI1i + IIIiiIIii / i1IIi
elif ooOOOoOooOoO == 333 :
 I1I1I ( )
 if 54 - 54: iIii1I11I1II1 % O0I11i1i11i1I - Ii / oooO0oOOOOo0o - ii1IiI1i . OOoO00o
elif ooOOOoOooOoO == 4 :
 O0oOoOOOoOO ( iIIiIi1 )
 if 11 - 11: O0I11i1i11i1I . ii1IiI1i * iIii1I111I11I * OoooooooOO + i1II1I11
elif ooOOOoOooOoO == 5 :
 ooOOoooooo ( )
 if 33 - 33: O0 * OOo000 - OO00OooO0OO % OO00OooO0OO
elif ooOOOoOooOoO == 6 :
 OO0Oooo0oOO0O ( )
 if 18 - 18: OO00OooO0OO / i1 * OO00OooO0OO + OO00OooO0OO * i11iIiiIii * O0I11i1i11i1I
elif ooOOOoOooOoO == 9 :
 xbmc . executebuiltin ( 'ActivateWindow(busydialog)' )
 tools . Trailer ( ) . play ( iIIiIi1 )
 xbmc . executebuiltin ( 'Dialog.Close(busydialog)' )
 if 11 - 11: i1II1I11 / IIIiiIIii - iIii1I111I11I * OoooooooOO + OoooooooOO . IIIiiIIii
elif ooOOOoOooOoO == 10 :
 oOO00oOO ( iIIiIi1 , II111iI111I1I )
 if 26 - 26: O000oo % O0I11i1i11i1I
elif ooOOOoOooOoO == 11 :
 o0oO ( )
 if 76 - 76: iIii1I111I11I * iiIIi1IiIi11
elif ooOOOoOooOoO == 12 :
 Ooo ( )
 if 52 - 52: Ii
elif ooOOOoOooOoO == 13 :
 catchup ( )
 if 19 - 19: OOooo000oo0
elif ooOOOoOooOoO == 14 :
 tvarchive ( i1i1i11IIi , II111iI111I1I )
 if 25 - 25: O000oo / i1II1I11
elif ooOOOoOooOoO == 15 :
 listcatchup2 ( )
 if 31 - 31: Ii . O0 % OOooo000oo0 . OOo000 + iIii1I111I11I
elif ooOOOoOooOoO == 16 :
 oOOOoo0O0oO ( )
 if 71 - 71: OO00OooO0OO . II111iiii
elif ooOOOoOooOoO == 17 :
 shortlinks . Get ( )
 if 62 - 62: OoooooooOO . OOoO00o
elif ooOOOoOooOoO == 19 :
 get ( )
 if 61 - 61: IIIiiIIii - Ii - i1IIi
elif ooOOOoOooOoO == 20 :
 OO0OoO0o00 ( iIIiIi1 )
 if 25 - 25: O0 * OOoO00o + O0I11i1i11i1I . OOo000 . OOo000
elif ooOOOoOooOoO == 21 :
 i11I1iIiII ( iIIiIi1 )
 if 58 - 58: OOooo000oo0
elif ooOOOoOooOoO == 22 :
 o0oo ( iIIiIi1 )
 if 53 - 53: i1IIi
elif ooOOOoOooOoO == 24 :
 OOO00O ( iIIiIi1 )
 if 59 - 59: OOo000
elif ooOOOoOooOoO == 2424 :
 oOOOOo0 ( iIIiIi1 )
 if 81 - 81: IIIiiIIii - IIIiiIIii . iiIIi1IiIi11
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
